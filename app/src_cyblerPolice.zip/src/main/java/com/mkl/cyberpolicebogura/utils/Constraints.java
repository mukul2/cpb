package com.mkl.cyberpolicebogura.utils;

/**
 * Created by mkl on 2/15/2019.
 */

public class Constraints {
    public  static String SUPER_ADMIN="0";
    public  static String ADMIN="1";
}
